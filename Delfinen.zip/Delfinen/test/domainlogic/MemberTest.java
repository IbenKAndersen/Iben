package domainlogic;

import dolphins.datasource.FileHandler;
import dolphins.domainlogic.Member;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;

public class MemberTest {

    public MemberTest() {
    }

    @Test
    public void createMembership() throws IOException {
        Member m = new Member(1, "Iben", LocalDate.of(1995,4,30), true);
        
        FileHandler handler = new FileHandler("TestFile.txt");
        handler.saveMember(m);
        
        List<Member> mList = (List) handler.readFile();
        m = mList.get(0);
        
        assertNotNull(m); //Assert
        assertEquals(1, m.getId());
        assertEquals("Iben", m.getName());
        assertEquals(LocalDate.of(1995,4,30), m.getBirthday());
        assertEquals(true, m.isMemberStatus());
    }
    
}
