package dolphins.datasource;

import dolphins.domainlogic.Member;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class FileHandler {

    File dM = new File("DolphinMembers.txt"); //C:\Users\ibenk\Documents\
    Member member;

    public FileHandler() {
    }
    
    public FileHandler(String path){
        this.dM = new File(path);
    }
    
    public void saveMember(Member member) throws IOException {
        this.member = member;
        writeFile();
        //members.add(m);
    }

//    public ArrayList<Member> getAllMembers() {
//        return members;
//    }
    
    public void writeFile() throws IOException {
        List<Member> list = readFile();
        list.add(member);
        dM.createNewFile();
        FileOutputStream fos = new FileOutputStream(dM);
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        oos.writeObject(list);
        oos.flush();
    }

    public List<Member> readFile() throws FileNotFoundException, IOException {
        try {
            if(!dM.exists()) {
                return new ArrayList<>();
            }
            FileInputStream fis = new FileInputStream(dM);
            ObjectInputStream ois = new ObjectInputStream(fis);
            List<Member> list = (List) ois.readObject();
            System.out.println(list);
            ois.close();
            return list;
        } catch (ClassNotFoundException ex) {
        }
        return new ArrayList<>();
    }

}
