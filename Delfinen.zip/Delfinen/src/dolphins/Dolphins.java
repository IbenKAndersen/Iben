package dolphins;

import dolphins.domainlogic.Member;
import java.time.LocalDate;
import java.util.ArrayList;

public class Dolphins {
    
    public static void main(String[] args) {
        
    }
    
}
