package dolphins.domainlogic;

public class Cashier {
    
}
