package dolphins.domainlogic;

import java.time.LocalDate;

public class MemberCompeting implements MemberInterface {
        
}
