package dolphins.domainlogic;

import java.io.IOException;
import java.time.LocalDate;

public class Controller {
    
    public static Member createMember(int id, String name, LocalDate birthday, boolean status) {
        Member m = new Member(id, name, birthday, status);
        return m;
    }

}