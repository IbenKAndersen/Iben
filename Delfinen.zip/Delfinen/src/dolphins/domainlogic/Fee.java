package dolphins.domainlogic;

public class Fee {
    
}
