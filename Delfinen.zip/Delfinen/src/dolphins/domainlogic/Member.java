package dolphins.domainlogic;

import java.io.File;
import java.io.FileWriter;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Arrays;

public class Member implements MemberInterface, Serializable {
    private int id;
    private String name;
    private LocalDate birthday;
    private boolean memberStatus;

    public Member(int id, String name, LocalDate birthday, boolean memberStatus) {
        this.id = id;
        this.name = name;
        this.birthday = birthday;
        this.memberStatus = memberStatus;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDate getBirthday() {
        return birthday;
    }
    
    public int getAge() {
        LocalDate today = LocalDate.now(); //den finder selv d.d.
        Period period = Period.between(birthday, today);
        int age = period.getYears(); 
        return age;
    }

    public boolean isMemberStatus() {
        return memberStatus;
    }

    public void setMemberStatus(boolean memberStatus) {
        this.memberStatus = memberStatus;
    }
    
    @Override
    public String toString() {
        return "Member " + "id nr.: " + id + ", name: " + name + ", birthday: " + birthday + ", member status: " + memberStatus;
    }
    
}
