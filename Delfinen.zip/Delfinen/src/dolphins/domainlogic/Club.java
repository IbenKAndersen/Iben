package dolphins.domainlogic;

public class Club {
    
}
