package dolphins.domainlogic;

public class Team {
    
}
