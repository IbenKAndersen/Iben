package dolphins.domainlogic;

public class Result {
    
}
