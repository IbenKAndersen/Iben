package dolphins.domainlogic;

public interface MemberInterface {
      
}
