package dolphins.domainlogic;

public class Coach {
    
}
