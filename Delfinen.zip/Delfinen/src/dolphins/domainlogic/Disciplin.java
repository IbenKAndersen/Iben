package dolphins.domainlogic;

public class Disciplin {
    
}
